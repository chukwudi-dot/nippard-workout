import { useState, useRef, useEffect } from 'react'

// ─── Data ────────────────────────────────────────────────────────────────────
const DAYS = [
  {
    id: 'upper-a',
    label: 'Upper A',
    tag: 'STRENGTH',
    day: 'MON',
    accent: '#E8FF47',
    bg: 'rgba(232,255,71,0.07)',
    focus: 'Heavy horizontal push / pull',
    exercises: [
      { name: 'Smith Machine Bench Press', sets: 4, reps: '5–6', rest: '3–4 min', equipment: 'Smith Machine', sub: 'Primary chest compound', cue: 'Tuck elbows 45°, squeeze shoulder blades, controlled 2-sec descent. Smith lets you go heavier safely solo.', gifQuery: 'bench press', muscle: 'Chest' },
      { name: 'Cable Seated Row', sets: 4, reps: '6–8', rest: '3–4 min', equipment: 'Lat/Row Machine', sub: 'Primary back compound', cue: 'Pull elbows tight to sides, hold 1 sec at peak. Full stretch on return — don\'t cut range short.', gifQuery: 'seated cable row', muscle: 'Back' },
      { name: 'Smith Machine Incline Press', sets: 3, reps: '10', rest: '2–3 min', equipment: 'Smith Machine', sub: 'Upper chest hypertrophy', cue: 'Set bench to 30–45°. Pause briefly at bottom to kill momentum. Targets the clavicular pec head.', gifQuery: 'incline bench press', muscle: 'Upper Chest' },
      { name: 'Lat Pulldown', sets: 3, reps: '10–12', rest: '2–3 min', equipment: 'Lat Pulldown Machine', sub: 'Lat width', cue: 'Shoulder-width grip, pull elbows DOWN and IN toward hips. Slight lean back is fine.', gifQuery: 'lat pulldown', muscle: 'Lats' },
      { name: 'Dumbbell Lateral Raise', sets: 3, reps: '15–20', rest: '1–2 min', equipment: 'Dumbbells', sub: 'Side delt isolation', cue: 'Lead with elbows, slight forward lean. Avoid shrugging. Control the lowering phase.', gifQuery: 'lateral raise', muscle: 'Side Delts' },
      { name: 'Cable Tricep Pushdown', sets: 3, reps: '12–15', rest: '1 min', equipment: 'Functional Cable', sub: 'Tricep isolation', cue: 'Spread the rope apart at the bottom. Lock upper arms at your sides — only forearms move.', gifQuery: 'tricep pushdown rope', muscle: 'Triceps' },
    ],
  },
  {
    id: 'lower-a',
    label: 'Lower A',
    tag: 'STRENGTH',
    day: 'TUE',
    accent: '#FF6B35',
    bg: 'rgba(255,107,53,0.07)',
    focus: 'Quad dominant / heavy compound',
    exercises: [
      { name: 'Smith Machine Back Squat', sets: 4, reps: '5–6', rest: '3–4 min', equipment: 'Smith Machine', sub: 'Primary leg compound', cue: 'Feet slightly forward of bar. 15° toe flare, drive knees out. The Smith lets you go deep safely.', gifQuery: 'barbell squat', muscle: 'Quads' },
      { name: 'Dumbbell Romanian Deadlift', sets: 3, reps: '10', rest: '2–3 min', equipment: 'Dumbbells (40–50 lbs)', sub: 'Hamstring / glute hinge', cue: 'Neutral lower back, push hips BACK. Feel the stretch in hamstrings. Never round your spine.', gifQuery: 'romanian deadlift dumbbell', muscle: 'Hamstrings' },
      { name: 'Leg Extension', sets: 3, reps: '12–15', rest: '1–2 min', equipment: 'Leg Extension Machine', sub: 'Quad isolation', cue: 'Full range of motion. Squeeze and hold 1 sec at the top. Control the descent.', gifQuery: 'leg extension', muscle: 'Quads' },
      { name: 'Lying Leg Curl', sets: 3, reps: '10–12', rest: '1–2 min', equipment: 'Leg Curl Machine', sub: 'Hamstring isolation', cue: 'Squeeze hamstrings hard. Slow 3-sec eccentric. Don\'t let hips rise off the pad.', gifQuery: 'lying leg curl', muscle: 'Hamstrings' },
      { name: 'Cable Pull-Through', sets: 3, reps: '15', rest: '1 min', equipment: 'Functional Cable (low pulley)', sub: 'Glute / posterior chain finisher', cue: 'Hip hinge — don\'t squat it. Squeeze glutes hard at the top. Keep arms passive throughout.', gifQuery: 'cable pull through', muscle: 'Glutes' },
    ],
  },
  {
    id: 'upper-b',
    label: 'Upper B',
    tag: 'VOLUME',
    day: 'THU',
    accent: '#A78BFA',
    bg: 'rgba(167,139,250,0.07)',
    focus: 'Vertical push / pull + isolation',
    exercises: [
      { name: 'Smith Machine Overhead Press', sets: 3, reps: '8–10', rest: '2–3 min', equipment: 'Smith Machine', sub: 'Shoulder compound', cue: 'Press in front of face. Squeeze glutes and brace core to avoid lower back arch.', gifQuery: 'overhead press barbell', muscle: 'Shoulders' },
      { name: 'Lat Pulldown (Underhand)', sets: 3, reps: '10–12', rest: '2–3 min', equipment: 'Lat Pulldown Machine', sub: 'Lats + bicep recruitment', cue: 'Supinated grip. Pull elbows to sides. More bicep involvement — great pairing with the press.', gifQuery: 'underhand lat pulldown', muscle: 'Lats' },
      { name: 'Cable Chest Fly', sets: 3, reps: '12–15', rest: '1–2 min', equipment: 'Cable Machine', sub: 'Chest isolation / stretch', cue: 'Slight bend in elbows. Focus on the STRETCH at the bottom — that\'s where growth happens.', gifQuery: 'cable chest fly', muscle: 'Chest' },
      { name: 'Dumbbell One-Arm Row', sets: 3, reps: '12', rest: '1–2 min', equipment: 'Dumbbells (40–50 lbs)', sub: 'Unilateral back thickness', cue: 'Brace knee on bench. Drive elbow up and BACK. Full stretch at the bottom every rep.', gifQuery: 'one arm dumbbell row', muscle: 'Back' },
      { name: 'Cable Face Pull', sets: 3, reps: '15–20', rest: '1 min', equipment: 'Functional Cable (high pulley)', sub: 'Rear delt / rotator cuff health', cue: 'Pull rope to FOREHEAD, spread arms OUT. Non-negotiable for shoulder health — every upper day.', gifQuery: 'cable face pull', muscle: 'Rear Delts' },
      { name: 'Dumbbell Supinated Curl', sets: 3, reps: '10–12', rest: '1 min', equipment: 'Dumbbells', sub: 'Bicep peak', cue: 'Supinate (rotate palm up) as you curl. Drive your PINKY into handle harder than index finger.', gifQuery: 'dumbbell bicep curl supinated', muscle: 'Biceps' },
    ],
  },
  {
    id: 'lower-b',
    label: 'Lower B',
    tag: 'VOLUME',
    day: 'FRI',
    accent: '#34D399',
    bg: 'rgba(52,211,153,0.07)',
    focus: 'Hip dominant / single-leg volume',
    exercises: [
      { name: 'Smith Machine Bulgarian Split Squat', sets: 3, reps: '10–12 ea.', rest: '2–3 min', equipment: 'Smith Machine', sub: 'Unilateral quad / glute', cue: 'Rear foot on bench, bar across upper traps. Big step forward. Sink straight down — don\'t lean.', gifQuery: 'bulgarian split squat', muscle: 'Quads' },
      { name: 'Dumbbell Romanian Deadlift', sets: 3, reps: '12', rest: '2 min', equipment: 'Dumbbells (35–45 lbs)', sub: 'Hamstring / glute volume', cue: 'Higher rep version of Lower A. Focus on the stretch and squeezing glutes at lockout.', gifQuery: 'romanian deadlift dumbbell', muscle: 'Hamstrings' },
      { name: 'Leg Extension', sets: 3, reps: '15', rest: '1–2 min', equipment: 'Leg Extension Machine', sub: 'Quad isolation (volume)', cue: 'Lighter weight, higher reps today. Slow 2-sec lowering phase. Feel the burn.', gifQuery: 'leg extension', muscle: 'Quads' },
      { name: 'Lying Leg Curl', sets: 3, reps: '12–15', rest: '1–2 min', equipment: 'Leg Curl Machine', sub: 'Hamstring isolation (volume)', cue: '3-second eccentric. Stretch the hamstring on the way down, squeeze on the way up.', gifQuery: 'lying leg curl', muscle: 'Hamstrings' },
      { name: 'Dumbbell Walking Lunge', sets: 3, reps: '12 steps ea.', rest: '1–2 min', equipment: 'Dumbbells (20–35 lbs each)', sub: 'Glute / quad finisher', cue: 'Long stride, knee hovers above floor. Stay upright. Use all available space.', gifQuery: 'dumbbell walking lunge', muscle: 'Glutes' },
      { name: 'Cable Pull-Through', sets: 3, reps: '15', rest: '1 min', equipment: 'Functional Cable (low pulley)', sub: 'Glute finisher', cue: 'Same as Lower A. Reinforce the hip hinge. Squeeze glutes aggressively at lockout.', gifQuery: 'cable pull through', muscle: 'Glutes' },
    ],
  },
]

const SCHEDULE = [
  { day: 'MON', label: 'Upper A', active: true, id: 'upper-a' },
  { day: 'TUE', label: 'Lower A', active: true, id: 'lower-a' },
  { day: 'WED', label: 'Rest', active: false },
  { day: 'THU', label: 'Upper B', active: true, id: 'upper-b' },
  { day: 'FRI', label: 'Lower B', active: true, id: 'lower-b' },
  { day: 'SAT', label: 'Rest', active: false },
  { day: 'SUN', label: 'Rest', active: false },
]

const TIPS = [
  { icon: '📈', title: 'Progressive Overload', body: 'Add 1 rep or 2.5–5 lbs each week. This single habit drives 90% of results.' },
  { icon: '🎯', title: 'Train Near Failure', body: 'Stop 2–3 reps short (RPE 7–8) on most sets. Last set of each exercise: RPE 9.' },
  { icon: '⏱️', title: 'Rest Times Matter', body: 'Compounds: 3–4 min. Isolation: 1–2 min. Cutting rest short kills strength output.' },
  { icon: '🔄', title: 'Deload Every 6–8 Weeks', body: 'Drop weight 40% for one week. Mandatory — this is when you actually grow.' },
  { icon: '🍳', title: 'Protein Target', body: '0.8–1g per lb of bodyweight daily. Spread across 4+ meals.' },
  { icon: '😴', title: 'Sleep = Gains', body: '7–9 hrs. Growth hormone peaks during deep sleep. Don\'t skip this.' },
]

// ─── Hooks ───────────────────────────────────────────────────────────────────
function useWgerGif(query, enabled) {
  const [gifUrl, setGifUrl] = useState(null)
  const [loading, setLoading] = useState(false)
  const cache = useRef({})

  useEffect(() => {
    if (!enabled || !query) return
    if (cache.current[query] !== undefined) {
      setGifUrl(cache.current[query])
      return
    }
    setLoading(true)
    setGifUrl(null)

    fetch(`https://wger.de/api/v2/exercise/search/?term=${encodeURIComponent(query)}&language=english&format=json`)
      .then(r => r.json())
      .then(data => {
        const id = data?.suggestions?.[0]?.data?.id
        if (!id) throw new Error('no result')
        return fetch(`https://wger.de/api/v2/exerciseimage/?exercise_base=${id}&format=json`)
      })
      .then(r => r.json())
      .then(img => {
        const url = img?.results?.find(i => i.is_main)?.image || img?.results?.[0]?.image || null
        cache.current[query] = url
        setGifUrl(url)
      })
      .catch(() => {
        cache.current[query] = null
        setGifUrl(null)
      })
      .finally(() => setLoading(false))
  }, [query, enabled])

  return { gifUrl, loading }
}

// ─── Components ──────────────────────────────────────────────────────────────
function SetTracker({ sets, accent }) {
  const [done, setDone] = useState([])
  const toggle = i => setDone(p => p.includes(i) ? p.filter(x => x !== i) : [...p, i])
  const allDone = done.length === sets

  return (
    <div>
      <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', letterSpacing: '1.5px', textTransform: 'uppercase', margin: '0 0 8px' }}>
        Track Sets
      </p>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        {Array.from({ length: sets }).map((_, i) => (
          <button
            key={i}
            onClick={e => { e.stopPropagation(); toggle(i) }}
            style={{
              width: 40, height: 40,
              borderRadius: 10,
              border: `1.5px solid ${done.includes(i) ? accent : 'rgba(255,255,255,0.15)'}`,
              background: done.includes(i) ? accent : 'transparent',
              color: done.includes(i) ? '#000' : 'rgba(255,255,255,0.3)',
              fontWeight: 800, fontSize: 13,
              cursor: 'pointer',
              transition: 'all 0.15s',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'inherit',
            }}
          >
            {done.includes(i) ? '✓' : i + 1}
          </button>
        ))}
        {done.length > 0 && (
          <span style={{ fontSize: 12, color: allDone ? accent : 'rgba(255,255,255,0.4)', fontWeight: 700 }}>
            {allDone ? '✅ Done!' : `${done.length}/${sets}`}
          </span>
        )}
      </div>
    </div>
  )
}

function DemoModal({ exercise, accent, onClose }) {
  const { gifUrl, loading } = useWgerGif(exercise?.gifQuery, !!exercise)

  useEffect(() => {
    const handler = e => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [onClose])

  if (!exercise) return null

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 999,
        background: 'rgba(0,0,0,0.88)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 20,
        backdropFilter: 'blur(8px)',
        WebkitBackdropFilter: 'blur(8px)',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: '#141417',
          border: `1px solid ${accent}30`,
          borderRadius: 20,
          width: '100%', maxWidth: 420,
          overflow: 'hidden',
          boxShadow: `0 0 60px ${accent}25`,
          maxHeight: '90vh',
          overflowY: 'auto',
        }}
      >
        {/* Header */}
        <div style={{
          padding: '16px 20px',
          borderBottom: '1px solid rgba(255,255,255,0.07)',
          display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
          position: 'sticky', top: 0, background: '#141417', zIndex: 1,
        }}>
          <div>
            <div style={{
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 20, fontWeight: 900, color: accent,
              textTransform: 'uppercase', letterSpacing: 0.5, lineHeight: 1.1,
            }}>
              {exercise.name}
            </div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)', marginTop: 3 }}>
              {exercise.sub} · {exercise.sets} × {exercise.reps}
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'rgba(255,255,255,0.08)',
              border: 'none', borderRadius: 8,
              color: 'rgba(255,255,255,0.5)',
              width: 32, height: 32,
              cursor: 'pointer', fontSize: 16,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}
          >✕</button>
        </div>

        {/* GIF / Image area */}
        <div style={{
          background: '#0a0a0c',
          minHeight: 240,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          position: 'relative',
        }}>
          {loading && (
            <div style={{ textAlign: 'center', color: 'rgba(255,255,255,0.3)' }}>
              <div style={{ fontSize: 32, marginBottom: 8, animation: 'spin 1s linear infinite' }}>⏳</div>
              <div style={{ fontSize: 13 }}>Loading demo...</div>
            </div>
          )}
          {!loading && gifUrl && (
            <img
              src={gifUrl}
              alt={`${exercise.name} demonstration`}
              style={{ width: '100%', maxHeight: 300, objectFit: 'contain' }}
            />
          )}
          {!loading && !gifUrl && (
            <div style={{ textAlign: 'center', padding: 24 }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>🏋️</div>
              <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.3)', marginBottom: 16 }}>
                Image not available for this exercise
              </p>
              <a
                href={`https://www.youtube.com/results?search_query=${encodeURIComponent(exercise.name + ' exercise form tutorial')}`}
                target="_blank"
                rel="noreferrer"
                style={{
                  display: 'inline-block',
                  padding: '10px 18px',
                  background: accent,
                  color: '#000',
                  borderRadius: 8,
                  fontSize: 13,
                  fontWeight: 700,
                  textDecoration: 'none',
                }}
              >
                ▶ Watch on YouTube
              </a>
            </div>
          )}
          {/* Muscle badge */}
          <div style={{
            position: 'absolute', top: 10, right: 10,
            background: `${accent}20`, border: `1px solid ${accent}40`,
            borderRadius: 20, padding: '4px 10px',
            fontSize: 11, color: accent, fontWeight: 700,
            textTransform: 'uppercase', letterSpacing: 1,
          }}>
            {exercise.muscle}
          </div>
        </div>

        {/* Cues */}
        <div style={{ padding: '16px 20px 20px' }}>
          <p style={{ fontSize: 10, letterSpacing: '2px', color: 'rgba(255,255,255,0.25)', textTransform: 'uppercase', margin: '0 0 8px' }}>
            Form Cues
          </p>
          <div style={{
            background: `${accent}0F`,
            borderLeft: `3px solid ${accent}`,
            borderRadius: '0 8px 8px 0',
            padding: '10px 12px',
            fontSize: 14, color: 'rgba(255,255,255,0.75)',
            lineHeight: 1.6,
            marginBottom: 12,
          }}>
            {exercise.cue}
          </div>
          <a
            href={`https://www.youtube.com/results?search_query=${encodeURIComponent('Jeff Nippard ' + exercise.name)}`}
            target="_blank"
            rel="noreferrer"
            style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '10px 14px',
              background: 'rgba(255,255,255,0.04)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: 10,
              color: 'rgba(255,255,255,0.5)',
              fontSize: 13, fontWeight: 600,
              textDecoration: 'none',
            }}
          >
            <span style={{ fontSize: 16 }}>▶</span>
            Search "{exercise.name}" on YouTube
          </a>
        </div>
      </div>
    </div>
  )
}

function ExerciseCard({ ex, index, accent, expanded, onToggle, onDemo }) {
  return (
    <div style={{
      background: expanded ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.03)',
      border: `1px solid ${expanded ? accent + '40' : 'rgba(255,255,255,0.07)'}`,
      borderRadius: 14, overflow: 'hidden', transition: 'all 0.2s',
    }}>
      <div
        onClick={onToggle}
        style={{ padding: '14px 16px', display: 'flex', gap: 14, alignItems: 'flex-start', cursor: 'pointer' }}
      >
        <div style={{
          flexShrink: 0, width: 32, height: 32, borderRadius: 8,
          background: expanded ? accent : 'rgba(255,255,255,0.08)',
          color: expanded ? '#000' : 'rgba(255,255,255,0.4)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontWeight: 900, fontSize: 13,
          fontFamily: "'Barlow Condensed', sans-serif",
          transition: 'all 0.2s', marginTop: 2, flexShrink: 0,
        }}>
          {String(index + 1).padStart(2, '0')}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontWeight: 700, fontSize: 15, color: '#f5f5f7', lineHeight: 1.2,
            fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: 0.3,
          }}>
            {ex.name}
          </div>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)', marginTop: 3 }}>
            {ex.sub} · {ex.equipment}
          </div>
        </div>
        <div style={{ flexShrink: 0, textAlign: 'right', display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
          <div style={{
            fontFamily: "'Barlow Condensed', sans-serif",
            fontSize: 22, fontWeight: 700, color: accent, lineHeight: 1,
          }}>
            {ex.sets}×{ex.reps}
          </div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)' }}>{ex.rest}</div>
          <button
            onClick={e => { e.stopPropagation(); onDemo(ex) }}
            style={{
              display: 'flex', alignItems: 'center', gap: 4,
              padding: '4px 10px',
              background: `${accent}18`, border: `1px solid ${accent}35`,
              borderRadius: 20, color: accent,
              fontSize: 11, fontWeight: 700,
              cursor: 'pointer', letterSpacing: 0.5,
              fontFamily: 'inherit',
            }}
          >
            ▶ Demo
          </button>
        </div>
      </div>

      {expanded && (
        <div style={{
          padding: '12px 16px 16px',
          borderTop: `1px solid ${accent}20`,
        }}>
          <div style={{
            background: `${accent}12`,
            borderLeft: `3px solid ${accent}`,
            borderRadius: '0 8px 8px 0',
            padding: '10px 12px',
            fontSize: 13, color: 'rgba(255,255,255,0.75)',
            lineHeight: 1.55, marginBottom: 14,
          }}>
            {ex.cue}
          </div>
          <SetTracker sets={ex.sets} accent={accent} />
        </div>
      )}
    </div>
  )
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [activeId, setActiveId] = useState('upper-a')
  const [expandedEx, setExpandedEx] = useState(null)
  const [showTips, setShowTips] = useState(false)
  const [view, setView] = useState('workout')
  const [demoExercise, setDemoExercise] = useState(null)

  const day = DAYS.find(d => d.id === activeId)

  const switchDay = id => { setActiveId(id); setExpandedEx(null) }

  // Safe area padding for iPhones with notch/home indicator
  const safeTop = 'env(safe-area-inset-top, 0px)'
  const safeBottom = 'env(safe-area-inset-bottom, 0px)'

  return (
    <div style={{
      minHeight: '100vh',
      background: '#0c0c0e',
      color: '#f5f5f7',
      fontFamily: "'DM Sans', system-ui, sans-serif",
      paddingBottom: `calc(80px + ${safeBottom})`,
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800;900&family=DM+Sans:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; margin: 0; padding: 0; }
        ::-webkit-scrollbar { display: none; }
        button, a { font-family: 'DM Sans', sans-serif; }
        html { -webkit-text-size-adjust: 100%; }
        body { padding-top: ${safeTop}; }
      `}</style>

      <DemoModal exercise={demoExercise} accent={day.accent} onClose={() => setDemoExercise(null)} />

      {/* Header */}
      <div style={{
        padding: '24px 20px 18px',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: -60, right: -40,
          width: 220, height: 220,
          background: `radial-gradient(circle, ${day.accent}15 0%, transparent 70%)`,
          pointerEvents: 'none', transition: 'all 0.4s',
        }} />

        <div style={{ position: 'relative' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: 20, padding: '4px 12px', marginBottom: 10,
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#34D399', display: 'inline-block' }} />
            <span style={{ fontSize: 11, letterSpacing: '1.5px', color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase' }}>
              Science-Based Program
            </span>
          </div>
          <h1 style={{
            fontFamily: "'Barlow Condensed', sans-serif",
            fontSize: 'clamp(32px, 8vw, 48px)',
            fontWeight: 900, lineHeight: 0.95, letterSpacing: '-0.5px',
            textTransform: 'uppercase', margin: '0 0 6px',
          }}>
            Jeff Nippard<br />
            <span style={{ color: day.accent, transition: 'color 0.3s' }}>Optimal Split</span>
          </h1>
          <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.3)' }}>
            Upper / Lower · 4×/week · Smith + Cables + Dumbbells
          </p>
        </div>

        <div style={{ display: 'flex', gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
          {[['4', 'Days/wk'], ['~55', 'Min/session'], ['2×', 'Per muscle']].map(([v, l]) => (
            <div key={l} style={{
              background: 'rgba(255,255,255,0.04)', borderRadius: 8, padding: '8px 14px', textAlign: 'center',
            }}>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 20, fontWeight: 800, color: day.accent, transition: 'color 0.3s' }}>{v}</div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)' }}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ maxWidth: 680, margin: '0 auto', padding: '0 16px' }}>

        {/* View Toggle */}
        <div style={{ display: 'flex', gap: 8, padding: '14px 0 10px' }}>
          {[['workout', 'Workout'], ['schedule', 'This Week']].map(([v, l]) => (
            <button key={v} onClick={() => setView(v)} style={{
              padding: '8px 18px', borderRadius: 20,
              border: `1.5px solid ${view === v ? day.accent : 'rgba(255,255,255,0.1)'}`,
              background: view === v ? day.accent : 'transparent',
              color: view === v ? '#000' : 'rgba(255,255,255,0.4)',
              fontWeight: 700, fontSize: 13, cursor: 'pointer', transition: 'all 0.2s',
            }}>
              {l}
            </button>
          ))}
        </div>

        {view === 'schedule' ? (
          <div>
            <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.25)', letterSpacing: '2px', textTransform: 'uppercase', margin: '0 0 14px' }}>
              Weekly Structure
            </p>
            {SCHEDULE.map(s => {
              const dayData = DAYS.find(d => d.id === s.id)
              return (
                <div key={s.day}
                  onClick={() => s.active && (switchDay(s.id), setView('workout'))}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 16,
                    padding: '14px 16px', marginBottom: 8, borderRadius: 12,
                    background: s.active ? 'rgba(255,255,255,0.04)' : 'transparent',
                    border: s.active ? '1px solid rgba(255,255,255,0.07)' : '1px solid rgba(255,255,255,0.03)',
                    cursor: s.active ? 'pointer' : 'default',
                  }}
                >
                  <div style={{
                    width: 44, fontFamily: "'Barlow Condensed', sans-serif",
                    fontSize: 15, fontWeight: 800, letterSpacing: 1,
                    color: s.active ? (dayData?.accent || '#fff') : 'rgba(255,255,255,0.15)',
                  }}>
                    {s.day}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 14, color: s.active ? '#f5f5f7' : 'rgba(255,255,255,0.2)' }}>
                      {s.label}
                    </div>
                    {s.active && dayData && (
                      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.3)', marginTop: 2 }}>{dayData.focus}</div>
                    )}
                  </div>
                  {s.active && <span style={{ color: 'rgba(255,255,255,0.2)', fontSize: 14 }}>→</span>}
                </div>
              )
            })}

            <div style={{ marginTop: 24 }}>
              <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.25)', letterSpacing: '2px', textTransform: 'uppercase', margin: '0 0 12px' }}>
                Your Equipment
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {[['🏗️', 'Smith Machine'], ['🏋️', 'Dumbbells (up to 50 lbs)'], ['🔗', 'Functional Cable'], ['⬆️', 'Chest/Shoulder Press Cable'], ['🦵', 'Leg Curl/Extension Machine'], ['⬇️', 'Lat Pulldown/Row Machine']].map(([icon, name]) => (
                  <div key={name} style={{
                    background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)',
                    borderRadius: 8, padding: '7px 12px',
                    fontSize: 12, color: 'rgba(255,255,255,0.55)',
                    display: 'flex', gap: 6, alignItems: 'center',
                  }}>
                    <span>{icon}</span>{name}
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div>
            {/* Day Selector */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 18, overflowX: 'auto', paddingBottom: 2 }}>
              {DAYS.map(d => (
                <button key={d.id} onClick={() => switchDay(d.id)} style={{
                  flexShrink: 0, padding: '10px 16px', borderRadius: 10,
                  border: `1.5px solid ${activeId === d.id ? d.accent : 'rgba(255,255,255,0.08)'}`,
                  background: activeId === d.id ? d.bg : 'transparent',
                  color: activeId === d.id ? d.accent : 'rgba(255,255,255,0.3)',
                  cursor: 'pointer', transition: 'all 0.2s', textAlign: 'left',
                }}>
                  <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 16, fontWeight: 800, letterSpacing: 0.5 }}>
                    {d.label}
                  </div>
                  <div style={{ fontSize: 10, opacity: 0.6, marginTop: 1 }}>{d.day} · {d.tag}</div>
                </button>
              ))}
            </div>

            {/* Day header */}
            <div style={{
              padding: '16px 18px', borderRadius: 14,
              background: day.bg, border: `1px solid ${day.accent}25`,
              marginBottom: 14,
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <div>
                <div style={{
                  fontFamily: "'Barlow Condensed', sans-serif",
                  fontSize: 22, fontWeight: 900, color: day.accent,
                  textTransform: 'uppercase', letterSpacing: 0.5,
                }}>
                  {day.label} — {day.tag}
                </div>
                <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>{day.focus}</div>
              </div>
              <div style={{
                fontFamily: "'Barlow Condensed', sans-serif",
                fontSize: 36, fontWeight: 900, color: day.accent, opacity: 0.2,
              }}>
                {day.day}
              </div>
            </div>

            {/* Hint banner */}
            <div style={{
              padding: '10px 14px', marginBottom: 12,
              background: `${day.accent}0C`, border: `1px solid ${day.accent}20`,
              borderRadius: 10, fontSize: 12, color: 'rgba(255,255,255,0.4)',
              display: 'flex', gap: 8, alignItems: 'center',
            }}>
              <span style={{ color: day.accent }}>▶</span>
              Tap <strong style={{ color: day.accent }}>Demo</strong> to see how it's done · Tap card for cues + set tracker
            </div>

            {/* Exercise cards */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {day.exercises.map((ex, i) => (
                <ExerciseCard
                  key={`${activeId}-${i}`}
                  ex={ex} index={i} accent={day.accent}
                  expanded={expandedEx === i}
                  onToggle={() => setExpandedEx(expandedEx === i ? null : i)}
                  onDemo={setDemoExercise}
                />
              ))}
            </div>

            {/* Tips */}
            <div style={{ marginTop: 28 }}>
              <button onClick={() => setShowTips(!showTips)} style={{
                width: '100%', padding: '14px 18px', borderRadius: 12,
                background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)',
                color: 'rgba(255,255,255,0.5)', fontWeight: 600, fontSize: 13,
                cursor: 'pointer', display: 'flex', justifyContent: 'space-between', textAlign: 'left',
              }}>
                <span>🧠 Nippard's Core Training Principles</span>
                <span style={{ transition: 'transform 0.2s', transform: showTips ? 'rotate(180deg)' : 'none', display: 'inline-block' }}>▾</span>
              </button>
              {showTips && (
                <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {TIPS.map((t, i) => (
                    <div key={i} style={{
                      padding: '14px 16px', borderRadius: 12,
                      background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)',
                      display: 'flex', gap: 12,
                    }}>
                      <span style={{ fontSize: 20, flexShrink: 0 }}>{t.icon}</span>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 13, color: day.accent, marginBottom: 3 }}>{t.title}</div>
                        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', lineHeight: 1.55 }}>{t.body}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
